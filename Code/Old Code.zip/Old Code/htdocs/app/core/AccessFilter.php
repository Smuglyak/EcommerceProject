<?php
namespace app\core;

abstract class AccessFilter{
	abstract public function execute();
}
?>